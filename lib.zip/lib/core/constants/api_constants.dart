const String API_KEY = 'your_api_key_here';
const String BASE_URL = 'https://newsapi.org/v2';
class ApiConstants {
  static const String baseUrl = 'https://newsapi.org/v2';
  static const String apiKey = 'your_api_key_here'; // استبدلها بمفتاحك
}