class Article {
  final String id;
  final String title;
  final String? imageUrl;
  final DateTime publishedAt;
  final String content;

  const Article({
    required this.id,
    required this.title,
    this.imageUrl,
    required this.publishedAt,
    required this.content,
  });
}