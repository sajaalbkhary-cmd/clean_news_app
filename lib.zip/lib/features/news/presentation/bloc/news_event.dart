part of 'news_bloc.dart'; // تأكد من تطابق الاسم

abstract class NewsEvent {}

class FetchNews extends NewsEvent {}