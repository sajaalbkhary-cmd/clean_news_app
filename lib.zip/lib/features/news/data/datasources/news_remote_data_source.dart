import 'package:dio/dio.dart';
import '../../domain/entities/article.dart';
import '../models/article_model.dart';

class NewsRemoteDataSource {
  final Dio dio;

  NewsRemoteDataSource({required this.dio});

  Future<List<Article>> getNews() async {
    try {
      final response = await dio.get(
        'https://newsapi.org/v2/top-headlines',
        queryParameters: {
          'country': 'us',
          'apiKey': 'YOUR_API_KEY', // استبدلها بمفتاحك من newsapi.org
        },
      );

      return (response.data['articles'] as List)
          .map((article) => ArticleModel.fromJson(article))
          .toList();
    } catch (e) {
      throw Exception('Failed to load news: $e');
    }
  }
}